so guys i warn yall the thing in the source code called BSoDRealCause is still non dangerous but the other fie named "BSoD" will cause a real Blue Screen of Death - educational purposes only

thanks for reading